import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-silde',
  templateUrl: './silde.component.html',
  styleUrls: ['./silde.component.css']
})
export class SildeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}